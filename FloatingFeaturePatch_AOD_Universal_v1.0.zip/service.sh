#!/system/bin/sh
# Mount patched XML at boot
MOD_XML="/data/adb/modules/floating_feature_aod_patch/system/etc/floating_feature.xml"
if [ -f "$MOD_XML" ]; then
    mount -o bind "$MOD_XML" /system/etc/floating_feature.xml
fi
