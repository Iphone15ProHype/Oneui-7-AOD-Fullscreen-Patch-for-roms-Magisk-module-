#!/system/bin/sh
# Magisk script to patch AOD_FULLSCREEN from 0 → 1

XML_PATH="/system/etc/floating_feature.xml"
MOD_XML_PATH="$MAGISK_MODULE_PATH/system/etc/floating_feature.xml"

mkdir -p "$(dirname "$MOD_XML_PATH")"

if [ -f "$XML_PATH" ]; then
    cp "$XML_PATH" "$MOD_XML_PATH"
    chmod 644 "$MOD_XML_PATH"
    sed -i 's#<SEC_FLOATING_FEATURE_LCD_CONFIG_AOD_FULLSCREEN>0</SEC_FLOATING_FEATURE_LCD_CONFIG_AOD_FULLSCREEN>#<SEC_FLOATING_FEATURE_LCD_CONFIG_AOD_FULLSCREEN>1</SEC_FLOATING_FEATURE_LCD_CONFIG_AOD_FULLSCREEN>#' "$MOD_XML_PATH"
fi
